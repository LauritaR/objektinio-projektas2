var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classstudentukas.html#aed1e12367d0833aa3d13a9283056579c',1,'studentukas']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../classstudentukas.html#a4c030b33758fa894bf635f45d5c6b245',1,'studentukas']]]
];
