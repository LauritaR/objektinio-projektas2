var searchData=
[
  ['setegzas_0',['setEgzas',['../classstudentukas.html#abb060b257defa9fc455328e12a6bb96f',1,'studentukas']]],
  ['setpavarde_1',['setPavarde',['../classzmogus.html#a33e3eb561d04e5eb0ee5a00de3b9f8e0',1,'zmogus::setPavarde()'],['../classstudentukas.html#ac9736fbcee6a63a148090ec7002e2081',1,'studentukas::setPavarde(string p)']]],
  ['setpazymiukai_2',['setPazymiukai',['../classstudentukas.html#a97385b667a8ef810e7bc0ddc3d365e83',1,'studentukas']]],
  ['setvardas_3',['setVardas',['../classzmogus.html#acacdb2524e91d2462d767e9208439717',1,'zmogus::setVardas()'],['../classstudentukas.html#a3571e81fcfe00ed2ca3a957eb86d20d7',1,'studentukas::setVardas()']]],
  ['skaitymas_4',['skaitymas',['../fun_8cpp.html#ae4a4676a64205f136ef13c6dbe9a1070',1,'fun.cpp']]],
  ['skirstymas_5',['skirstymas',['../fun_8cpp.html#a8aa77f1657cde4c8edce03a65a050ee6',1,'fun.cpp']]],
  ['spausdinimas_6',['spausdinimas',['../fun_8cpp.html#a16eeaeda81270384cb5b267e623832d5',1,'fun.cpp']]],
  ['studentukas_7',['studentukas',['../classstudentukas.html#a878e9a437b798a0e98b578518cf51e0a',1,'studentukas::studentukas()'],['../classstudentukas.html#a7cd799ee160c364efd9871cc3fe58603',1,'studentukas::studentukas(string vardas1, string pavarde1, vector&lt; int &gt; paz1, int egz1)'],['../classstudentukas.html#a9f7ba14e474e9367debaf5c66c1b3cf2',1,'studentukas::studentukas(const studentukas &amp;kitas)'],['../classstudentukas.html#ab95673d919768d6ea24d39e8fb09b1d6',1,'studentukas::studentukas(studentukas &amp;&amp;kitas)']]]
];
