var searchData=
[
  ['tuscias_0',['tuscias',['../classstudentukas.html#a47c6f69231af7149c5ef3b24b9f697f1',1,'studentukas']]]
];
