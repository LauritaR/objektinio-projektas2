var searchData=
[
  ['zmogus_0',['zmogus',['../classzmogus.html',1,'zmogus'],['../classzmogus.html#a3cb03824ec8269cf401cbf615e440833',1,'zmogus::zmogus()'],['../classzmogus.html#aaf1526d2d99fa9252a51c3ec689ee848',1,'zmogus::zmogus(string vardas, string pavarde)']]]
];
